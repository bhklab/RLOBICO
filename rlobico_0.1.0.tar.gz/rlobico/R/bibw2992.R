#' The 'bibw2992' Dataset
#' 
#' bibw2992 is a dataset used to power the examples run in this package\
#'
#' @format A data frame with N rows and P columns
#'
#' @source \url{http://r-pkgs.had.co.nz/data.html}
#' 
"bibw2992"